import streamlit as st
import torch
import clip
from PIL import Image
import pandas as pd
import os

# Load the CLIP model
device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/32", device=device)

# Load the captions dataset
captions_file = r"C:\Users\kancharr\Submission\Flickr8k.csv"
captions_df = pd.read_csv(captions_file, delimiter=",", header=0)
captions_df["image"] = captions_df["image"].str.split(".").str[0]

# Streamlit UI
st.title("Image Caption Retrieval")
st.write("Upload an image to retrieve the most similar caption.")

uploaded_file = st.file_uploader("Choose an image...", type="jpg")
input_caption = st.text_input("Enter a caption:")

if uploaded_file is not None:
    # Preprocess the uploaded image
    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption='Uploaded Image.', use_column_width=True)
    image = preprocess(image).unsqueeze(0).to(device)

    # Encode the image
    with torch.no_grad():
        image_features = model.encode_image(image)
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)

    # Find the most similar caption
    similarities = []
    for idx, row in captions_df.iterrows():
        caption = row['caption']
        text = clip.tokenize([caption]).to(device)
        with torch.no_grad():
            text_features = model.encode_text(text)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)
            similarity = (image_features @ text_features.T).item()
            similarities.append((similarity, caption))

    # Sort by similarity
    similarities.sort(reverse=True, key=lambda x: x[0])
    most_similar_caption = similarities[0][1]

    st.write("Most similar caption:")
    st.write(most_similar_caption)
    st.write("Similarity score:")
    st.write(similarities[0][0])

if input_caption:
    # Tokenize and encode the input caption
    text = clip.tokenize([input_caption]).to(device)
    with torch.no_grad():
        text_features = model.encode_text(text)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)

    # Find the most similar image
    similarities = []
    for idx, row in captions_df.iterrows():
        image_id = row['image']
        image_path = os.path.join(r"C:\Users\kancharr\Documents\IIIT\Flickr8k\Images", f"{image_id}.jpg")
        image = Image.open(image_path).convert("RGB")
        image = preprocess(image).unsqueeze(0).to(device)
        with torch.no_grad():
            image_features = model.encode_image(image)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True)
            similarity = (text_features @ image_features.T).item()
            similarities.append((similarity, image_path))

    # Sort by similarity
    similarities.sort(reverse=True, key=lambda x: x[0])
    most_similar_image_path = similarities[0][1]
    st.write("Most similar image:")
    st.image(most_similar_image_path, caption='Most Similar Image', use_column_width=True)
    st.write("Similarity score:")
    st.write(similarities[0][0])